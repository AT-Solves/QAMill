"""
test_math_utils.py
Intentionally incomplete test suite — AMIL will find the gaps
and auto-generate the missing tests.
"""
import pytest
from math_utils import (
    add, subtract, multiply, divide,
    is_even, is_positive, clamp, factorial,
    is_valid_age, max_of_three, percentage, is_leap_year
)


# ── Basic tests (some deliberately weak) ─────────────────────────────────────

def test_add_positive():
    assert add(2, 3) == 5

def test_add_zero():
    assert add(0, 5) == 5

def test_subtract_basic():
    assert subtract(10, 4) == 6

def test_multiply_basic():
    assert multiply(3, 4) == 12

def test_divide_basic():
    assert divide(10, 2) == 5.0

def test_divide_by_zero():
    assert divide(5, 0) is None

def test_is_even_true():
    assert is_even(4) is True

# NOTE: test_is_even_false is missing — AMIL should catch this

def test_is_positive_true():
    assert is_positive(5) is True

# NOTE: test_is_positive_zero is missing — boundary not tested

def test_clamp_within():
    assert clamp(5, 0, 10) == 5

# NOTE: clamp lower and upper bounds not tested

def test_factorial_zero():
    assert factorial(0) == 1

def test_factorial_basic():
    assert factorial(5) == 120

def test_is_valid_age_adult():
    assert is_valid_age(25) is True

# NOTE: boundary ages 0 and 150 not tested

def test_max_of_three_first():
    assert max_of_three(10, 5, 3) == 10

# NOTE: cases where b or c is max not tested

def test_percentage_basic():
    assert percentage(50, 100) == 50.0

def test_percentage_zero_total():
    assert percentage(10, 0) == 0.0

def test_is_leap_year_century():
    assert is_leap_year(2000) is True

# NOTE: non-leap years and century non-leap not tested
