"""
auto_healer.py
Game Changer 2: Takes a survived mutant, asks LLM to write a test
that kills it, verifies the test actually kills it, returns the
validated test ready to commit.
"""
import re
import asyncio
import tempfile
import os
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

from mutation_engine import Mutant


HEAL_PROMPT = """You are an expert software tester writing pytest test cases.

A mutation testing tool found a SURVIVED MUTANT — meaning the existing tests
did not catch this code change. Your job is to write a new test that kills it.

Original function:
```python
{original}
```

Mutant function (this is the bug you must expose):
```python
{mutant}
```

Mutation applied: {description}

Write a single pytest test function that:
1. Calls the function with specific inputs
2. Asserts the expected output that the ORIGINAL produces
3. Will FAIL when run against the mutant

Rules:
- Use function name: test_{fn_name}_kills_{mutant_id}
- Import the function from its module
- Use concrete values, no mocking
- One assert statement that distinguishes original from mutant

Respond ONLY with the Python test code, no explanation:
```python
<your test here>
```"""


@dataclass
class HealResult:
    success: bool
    test_code: str
    verified: bool       # True = test was confirmed to kill the mutant
    message: str


class AutoHealer:
    def __init__(self, llm_adapter, project_root: str):
        self.llm = llm_adapter
        self.project_root = Path(project_root)

    async def heal(self, mutant: Mutant, max_attempts: int = 3) -> HealResult:
        """
        Attempt up to max_attempts times to generate a verified killing test.
        """
        for attempt in range(1, max_attempts + 1):
            test_code = await self._generate_test(mutant)
            if not test_code:
                continue

            verified = await self._verify_test_kills_mutant(mutant, test_code)
            if verified:
                return HealResult(
                    success=True,
                    test_code=test_code,
                    verified=True,
                    message=f"Verified on attempt {attempt}"
                )

        # Return last generated test even if unverified
        test_code = await self._generate_test(mutant)
        return HealResult(
            success=True,
            test_code=test_code or "",
            verified=False,
            message="Generated but not verified — review before committing"
        )

    async def _generate_test(self, mutant: Mutant) -> Optional[str]:
        try:
            prompt = HEAL_PROMPT.format(
                original=mutant.original_src,
                mutant=mutant.mutant_src,
                description=mutant.description,
                fn_name=mutant.function_name,
                mutant_id=mutant.id.lower(),
            )
            raw = await self.llm.call_async(prompt, max_tokens=600)

            # Extract code block
            match = re.search(r"```python\s*(.*?)```", raw, re.DOTALL)
            if match:
                return match.group(1).strip()

            # Fallback: if no fences, take all lines starting with def/import
            lines = [l for l in raw.split("\n")
                     if l.strip().startswith(("def ", "import ", "from ", "assert", "    "))]
            return "\n".join(lines).strip() or None

        except Exception:
            return None

    async def _verify_test_kills_mutant(self, mutant: Mutant,
                                        test_code: str) -> bool:
        """
        Run the generated test against the mutant source.
        If the test fails (exit != 0) → it kills the mutant → verified.
        """
        with tempfile.TemporaryDirectory(prefix="amil_verify_") as tmpdir:
            tmp = Path(tmpdir)

            # Write the mutant version of the file
            rel_path = Path(mutant.file_path).relative_to(self.project_root)
            module_file = tmp / rel_path.name
            module_file.write_text(mutant.mutant_src)

            # Write the generated test file
            test_file = tmp / f"test_amil_{mutant.id}.py"
            # Patch import to use local module
            module_name = rel_path.stem
            patched = test_code.replace(
                f"from {rel_path.parent}.{module_name} import",
                f"from {module_name} import"
            ).replace(
                f"from {module_name} import",
                f"from {module_name} import"
            )
            test_file.write_text(patched)

            try:
                proc = await asyncio.create_subprocess_exec(
                    "pytest", str(test_file), "--tb=no", "-q",
                    cwd=str(tmp),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
                # Non-zero = test failed against mutant = test kills the mutant
                return proc.returncode != 0
            except Exception:
                return False
