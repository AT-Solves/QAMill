/**
 * extension.ts
 * VS Code extension entry point for AMIL.
 * Spawns Python backend, opens live dashboard webview.
 */
import * as vscode from "vscode";
import * as path from "path";
import * as cp from "child_process";
import * as http from "http";

let backendProcess: cp.ChildProcess | undefined;
let dashboardPanel: vscode.WebviewPanel | undefined;
let statusBarItem: vscode.StatusBarItem;

export function activate(context: vscode.ExtensionContext) {
  // Status bar pill
  statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBarItem.text = "$(beaker) AMIL";
  statusBarItem.tooltip = "AMIL Mutation Testing — click to run";
  statusBarItem.command = "amil.runAnalysis";
  statusBarItem.show();
  context.subscriptions.push(statusBarItem);

  // ── Commands ──────────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand("amil.runAnalysis", () => runAnalysis(context)),
    vscode.commands.registerCommand("amil.stopAnalysis", stopAnalysis),
    vscode.commands.registerCommand("amil.selectLLM", selectLLM),
  );
}

export function deactivate() {
  stopAnalysis();
}

// ── Run Analysis ─────────────────────────────────────────────────────────────

async function runAnalysis(context: vscode.ExtensionContext) {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showErrorMessage("AMIL: Open a source file to analyze.");
    return;
  }

  const filePath = editor.document.fileName;
  const projectRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  if (!projectRoot) {
    vscode.window.showErrorMessage("AMIL: Open a workspace folder first.");
    return;
  }

  const config = vscode.workspace.getConfiguration("amil");
  const llmProvider: string = config.get("llmProvider", "none");
  const port: number = config.get("backendPort", 8765);

  // Start backend if not running
  const backendReady = await ensureBackendRunning(context, port);
  if (!backendReady) {
    vscode.window.showErrorMessage("AMIL: Could not start backend. Check Python installation.");
    return;
  }

  // Open or reveal dashboard panel
  openDashboard(context, port);

  // Trigger analysis
  const payload = {
    file_path: filePath,
    project_root: projectRoot,
    llm_provider: llmProvider,
    llm_api_key: getApiKey(config, llmProvider),
    auto_heal: config.get("autoHeal", true),
    detect_equivalents: config.get("detectEquivalents", true),
  };

  try {
    const jobResp = await postJson(`http://localhost:${port}/analyze`, payload);
    dashboardPanel?.webview.postMessage({
      type: "job_started",
      job_id: jobResp.job_id,
      stream_url: jobResp.stream_url,
      file: path.basename(filePath),
    });
    statusBarItem.text = "$(sync~spin) AMIL Running...";
  } catch (err) {
    vscode.window.showErrorMessage(`AMIL: Analysis failed — ${err}`);
  }
}

// ── Backend lifecycle ─────────────────────────────────────────────────────────

async function ensureBackendRunning(context: vscode.ExtensionContext,
                                    port: number): Promise<boolean> {
  // Check if already running
  if (await isPortOpen(port)) return true;

  const backendDir = path.join(context.extensionPath, "..", "backend");
  backendProcess = cp.spawn("python", ["main.py"], {
    cwd: backendDir,
    detached: false,
    stdio: ["ignore", "pipe", "pipe"],
  });

  backendProcess.stderr?.on("data", (d) =>
    console.error("[AMIL backend]", d.toString())
  );

  // Wait up to 8 seconds for backend to be ready
  for (let i = 0; i < 16; i++) {
    await sleep(500);
    if (await isPortOpen(port)) return true;
  }
  return false;
}

function stopAnalysis() {
  if (backendProcess) {
    backendProcess.kill();
    backendProcess = undefined;
  }
  statusBarItem.text = "$(beaker) AMIL";
}

function isPortOpen(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const req = http.get(`http://localhost:${port}/health`, (res) => {
      resolve(res.statusCode === 200);
    });
    req.on("error", () => resolve(false));
    req.setTimeout(500, () => { req.destroy(); resolve(false); });
  });
}

// ── Dashboard Webview ─────────────────────────────────────────────────────────

function openDashboard(context: vscode.ExtensionContext, port: number) {
  if (dashboardPanel) {
    dashboardPanel.reveal(vscode.ViewColumn.Beside);
    return;
  }

  dashboardPanel = vscode.window.createWebviewPanel(
    "amilDashboard",
    "AMIL Dashboard",
    vscode.ViewColumn.Beside,
    {
      enableScripts: true,
      localResourceRoots: [
        vscode.Uri.joinPath(context.extensionUri, "media"),
      ],
    }
  );

  dashboardPanel.webview.html = getDashboardHtml(port);

  // Handle messages from webview (e.g. "open file at line X")
  dashboardPanel.webview.onDidReceiveMessage((msg) => {
    if (msg.type === "open_file") {
      vscode.workspace.openTextDocument(msg.file).then((doc) => {
        vscode.window.showTextDocument(doc).then((editor) => {
          const line = new vscode.Range(msg.line - 1, 0, msg.line - 1, 0);
          editor.revealRange(line, vscode.TextEditorRevealType.InCenter);
        });
      });
    }
    if (msg.type === "analysis_complete") {
      statusBarItem.text = `$(beaker) AMIL ${msg.true_score}%`;
    }
  });

  dashboardPanel.onDidDispose(() => {
    dashboardPanel = undefined;
    statusBarItem.text = "$(beaker) AMIL";
  });
}

// ── LLM selector quick-pick ───────────────────────────────────────────────────

async function selectLLM() {
  const choice = await vscode.window.showQuickPick(
    [
      { label: "$(circle-slash) None — in-house AST only", value: "none" },
      { label: "$(sparkle) Claude (Anthropic)",            value: "claude" },
      { label: "$(sparkle) GPT-4o (OpenAI)",              value: "gpt" },
      { label: "$(sparkle) Grok (xAI)",                   value: "grok" },
      { label: "$(home) Ollama — fully offline",           value: "inhouse" },
    ],
    { placeHolder: "Select LLM provider for AMIL" }
  );
  if (choice) {
    await vscode.workspace.getConfiguration("amil").update(
      "llmProvider", choice.value, vscode.ConfigurationTarget.Workspace
    );
    vscode.window.showInformationMessage(`AMIL: LLM set to ${choice.label}`);
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function getApiKey(config: vscode.WorkspaceConfiguration, provider: string): string {
  const keys: Record<string, string> = {
    claude: config.get("anthropicApiKey", ""),
    gpt:    config.get("openaiApiKey", ""),
    grok:   config.get("xaiApiKey", ""),
  };
  return keys[provider] || "";
}

function postJson(url: string, body: object): Promise<any> {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) },
    }, (res) => {
      let raw = "";
      res.on("data", (c) => raw += c);
      res.on("end", () => {
        try { resolve(JSON.parse(raw)); }
        catch { reject(new Error(raw)); }
      });
    });
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }

// ── Dashboard HTML (inlined) ──────────────────────────────────────────────────

function getDashboardHtml(port: number): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AMIL Dashboard</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
       background:var(--vscode-editor-background);color:var(--vscode-editor-foreground);
       font-size:13px;line-height:1.5;padding:16px}
  h2{font-size:15px;font-weight:600;margin-bottom:12px;opacity:.9}
  .score-row{display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap}
  .score-card{flex:1;min-width:90px;background:var(--vscode-sideBar-background);
              border:1px solid var(--vscode-widget-border);border-radius:6px;
              padding:10px 14px}
  .score-card .val{font-size:22px;font-weight:700;margin-top:2px}
  .score-card .lbl{font-size:11px;opacity:.6;text-transform:uppercase;letter-spacing:.05em}
  .true-score .val{color:#4ec9a0}
  .raw-score  .val{color:#ce9178}
  .bar-wrap{background:var(--vscode-widget-border);border-radius:3px;height:8px;margin-bottom:16px;overflow:hidden}
  .bar-fill{height:100%;border-radius:3px;background:#4ec9a0;width:0;transition:width .4s ease}
  .feed{max-height:420px;overflow-y:auto}
  .event{display:flex;align-items:flex-start;gap:8px;padding:7px 0;
         border-bottom:1px solid var(--vscode-widget-border)}
  .event:last-child{border-bottom:none}
  .badge{font-size:11px;font-weight:600;padding:2px 7px;border-radius:20px;flex-shrink:0;margin-top:1px}
  .b-killed{background:#1e3a2f;color:#4ec9a0}
  .b-survived{background:#3a1e1e;color:#f48771}
  .b-equivalent{background:#2a2a1e;color:#dcdcaa}
  .b-error{background:#2a1e2a;color:#c586c0}
  .b-info{background:transparent;color:var(--vscode-descriptionForeground)}
  .event-body{flex:1}
  .event-title{font-weight:500}
  .event-sub{font-size:11px;opacity:.6;margin-top:2px}
  .test-block{background:var(--vscode-textCodeBlock-background);border-radius:4px;
              padding:8px;margin-top:6px;font-family:monospace;font-size:11px;
              white-space:pre-wrap;max-height:120px;overflow-y:auto;
              border:1px solid var(--vscode-widget-border)}
  .verified{color:#4ec9a0;font-size:10px;margin-left:6px}
  .status-line{opacity:.5;font-style:italic;padding:6px 0;font-size:12px}
  .progress-label{font-size:11px;opacity:.5;margin-bottom:4px}
  #waiting{opacity:.5;padding:20px 0;text-align:center}
</style>
</head>
<body>
<h2>AMIL — Mutation Analysis</h2>

<div class="score-row">
  <div class="score-card true-score">
    <div class="lbl">True score</div>
    <div class="val" id="true-score">—</div>
  </div>
  <div class="score-card raw-score">
    <div class="lbl">Raw score</div>
    <div class="val" id="raw-score">—</div>
  </div>
  <div class="score-card">
    <div class="lbl">Killed</div>
    <div class="val" id="killed-count">0</div>
  </div>
  <div class="score-card">
    <div class="lbl">Survived</div>
    <div class="val" id="survived-count">0</div>
  </div>
  <div class="score-card">
    <div class="lbl">Equivalent</div>
    <div class="val" id="equiv-count">0</div>
  </div>
</div>

<div class="progress-label" id="progress-label">Waiting for analysis...</div>
<div class="bar-wrap"><div class="bar-fill" id="bar"></div></div>

<div class="feed" id="feed">
  <div id="waiting">Right-click a file → Run AMIL Mutation Analysis</div>
</div>

<script>
const vscode = acquireVsCodeApi();
let es = null;

window.addEventListener('message', e => {
  const msg = e.data;
  if (msg.type === 'job_started') {
    clearFeed();
    addStatus('Analyzing ' + msg.file + ' · LLM: ' + (msg.llm_provider || 'none'));
    connectStream(msg.stream_url);
  }
});

function connectStream(url) {
  if (es) es.close();
  es = new EventSource(url);
  es.onmessage = ev => handleEvent(JSON.parse(ev.data));
  es.onerror = () => addStatus('Stream disconnected');
}

function handleEvent(e) {
  if (e.type === 'ping') return;

  if (e.type === 'status' || e.type === 'healing') {
    addStatus(e.message);
    return;
  }

  if (e.type === 'start') {
    document.getElementById('progress-label').textContent =
      'Analyzing ' + e.total + ' mutants...';
    return;
  }

  if (e.type === 'mutant_result') {
    updateScores(e);
    updateBar(e.index, e.total);
    addMutantRow(e);
    return;
  }

  if (e.type === 'complete') {
    updateScores(e);
    document.getElementById('progress-label').textContent =
      'Complete — ' + e.total + ' mutants analysed';
    document.getElementById('bar').style.width = '100%';
    addStatus('Done. True score: ' + e.true_score + '% · Raw: ' + e.raw_score + '%');
    vscode.postMessage({ type: 'analysis_complete', true_score: e.true_score });
    if (es) { es.close(); es = null; }
    return;
  }

  if (e.type === 'error') {
    addStatus('Error: ' + e.message);
  }
}

function updateScores(e) {
  if (e.true_score !== undefined) document.getElementById('true-score').textContent = e.true_score + '%';
  if (e.raw_score  !== undefined) document.getElementById('raw-score').textContent  = e.raw_score  + '%';
  if (e.killed     !== undefined) document.getElementById('killed-count').textContent   = e.killed;
  if (e.survived   !== undefined) document.getElementById('survived-count').textContent = e.survived;
  if (e.equivalent !== undefined) document.getElementById('equiv-count').textContent    = e.equivalent;
}

function updateBar(index, total) {
  const pct = Math.round(index / total * 100);
  document.getElementById('bar').style.width = pct + '%';
  document.getElementById('progress-label').textContent =
    'Progress: ' + index + ' / ' + total + ' mutants';
}

function addMutantRow(e) {
  const feed = document.getElementById('feed');
  const div = document.createElement('div');
  div.className = 'event';

  const badge = { killed:'b-killed', survived:'b-survived',
                  equivalent:'b-equivalent', error:'b-error' }[e.status] || 'b-info';
  const icon  = { killed:'✓', survived:'✗', equivalent:'≡', error:'!' }[e.status] || '·';

  let extra = '';
  if (e.reason)
    extra += '<div class="event-sub">' + esc(e.reason) + '</div>';
  if (e.suggested_test) {
    const verified = e.test_verified ? '<span class="verified">✓ verified</span>' : '';
    extra += '<div class="test-block">' + esc(e.suggested_test) + '</div>' + verified;
  }

  div.innerHTML =
    '<span class="badge ' + badge + '">' + icon + ' ' + e.status.toUpperCase() + '</span>' +
    '<div class="event-body">' +
      '<span class="event-title">' + esc(e.mutant_id) + ' · ' +
        esc(e.function) + ':' + e.line + ' · ' + esc(e.description) + '</span>' +
      '<span class="event-sub">' + esc(e.operator) + '</span>' +
      extra +
    '</div>';

  feed.appendChild(div);
  feed.scrollTop = feed.scrollHeight;
}

function addStatus(msg) {
  const feed = document.getElementById('feed');
  const d = document.createElement('div');
  d.className = 'status-line';
  d.textContent = msg;
  feed.appendChild(d);
}

function clearFeed() {
  const feed = document.getElementById('feed');
  feed.innerHTML = '';
  document.getElementById('bar').style.width = '0';
  ['true-score','raw-score','killed-count','survived-count','equiv-count']
    .forEach(id => document.getElementById(id).textContent = id.includes('score') ? '—' : '0');
}

function esc(s) {
  if (!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
</script>
</body>
</html>`;
}
