# AMIL — Autonomous Mutation Intelligence Loop

AI-powered mutation testing with equivalent mutant detection,
self-healing test generation, and a live VS Code dashboard.

## Project structure

```
amil/
├── backend/               Python engine (FastAPI + SSE)
│   ├── main.py            API server — start this first
│   ├── mutation_engine.py AST-based in-house mutant generation
│   ├── equivalent_detector.py  3-stage: rules → Z3 → LLM
│   ├── llm_adapter.py     Claude / GPT / Grok / Ollama switcher
│   ├── test_runner.py     Wraps pytest/jest, never touches originals
│   ├── auto_healer.py     Generates + verifies killing tests
│   └── requirements.txt
├── vscode-extension/      VS Code extension (TypeScript)
│   ├── package.json
│   └── src/extension.ts   Spawns backend, opens live dashboard
└── sample_project/        Demo target (run AMIL on this first)
    ├── math_utils.py
    └── tests/test_math_utils.py
```

## Quick start — backend only (no VS Code needed for demo)

```bash
cd backend
pip install -r requirements.txt

# Start the server
python main.py
# Server runs at http://localhost:8765
```

Trigger an analysis via curl (or any HTTP client):

```bash
curl -X POST http://localhost:8765/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "file_path": "/absolute/path/to/amil/sample_project/math_utils.py",
    "project_root": "/absolute/path/to/amil/sample_project",
    "llm_provider": "none",
    "auto_heal": false,
    "detect_equivalents": true
  }'
# Returns: {"job_id": "abc-123", "stream_url": "http://localhost:8765/stream/abc-123"}

# Watch the live stream
curl -N http://localhost:8765/stream/abc-123
```

## Quick start — with LLM (Claude example)

```bash
curl -X POST http://localhost:8765/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "file_path": "/path/to/sample_project/math_utils.py",
    "project_root": "/path/to/sample_project",
    "llm_provider": "claude",
    "llm_api_key": "sk-ant-...",
    "auto_heal": true,
    "detect_equivalents": true
  }'
```

## LLM providers

| Provider   | Config value | Needs              |
|------------|-------------|--------------------|
| None       | `"none"`    | Nothing            |
| Claude     | `"claude"`  | ANTHROPIC_API_KEY  |
| GPT-4o     | `"gpt"`     | OPENAI_API_KEY     |
| Grok       | `"grok"`    | XAI_API_KEY        |
| Ollama     | `"inhouse"` | Ollama running locally |

## VS Code extension setup

```bash
cd vscode-extension
npm install
npm run compile

# Press F5 in VS Code to launch Extension Development Host
# Right-click any .py file → "AMIL: Run Mutation Analysis"
```

Set your LLM in VS Code settings:
- Open Command Palette → "AMIL: Select LLM Provider"
- Or edit settings.json: `"amil.llmProvider": "claude"`

## What AMIL reports

Each mutant gets one of four statuses:

- **KILLED** — your tests caught the mutation (good)
- **SURVIVED** — mutation went undetected (test gap found)
- **EQUIVALENT** — mutation is semantically identical to original (filtered from score)
- **ERROR** — test execution failed

**True score** = killed / (killed + survived) — excludes equivalents  
**Raw score**  = killed / all mutants — what other tools show (inflated)

## Supported mutation operators

| Code  | Name                          | Example             |
|-------|-------------------------------|---------------------|
| AOR   | Arithmetic operator replacement | `+` → `-`         |
| ROR   | Relational operator replacement | `==` → `!=`       |
| LCR   | Logical connector replacement  | `and` → `or`      |
| BCR   | Boolean constant replacement   | `True` → `False`  |
| RVR   | Return value replacement       | `return x` → `return None` |

## Adding more languages

The backend is language-agnostic at the API level.
To add JavaScript/TypeScript support, implement a `JSMutationEngine`
that uses the `@babel/parser` AST and drop it into `mutation_engine.py`
behind a `language` flag in the request.
