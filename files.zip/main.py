"""
main.py
FastAPI backend — runs locally on port 8765.
Streams real-time mutation results via Server-Sent Events.
VS Code extension and browser dashboard both connect to this.
"""
import asyncio
import json
import uuid
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from mutation_engine import MutationEngine
from equivalent_detector import EquivalentDetector
from test_runner import TestRunner
from auto_healer import AutoHealer
from llm_adapter import create_adapter

app = FastAPI(title="AMIL Mutation Testing Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Active jobs: job_id → asyncio.Queue of SSE event dicts
_jobs: dict[str, asyncio.Queue] = {}
_job_summaries: dict[str, dict] = {}


# ── Request / Response models ──────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    file_path: str
    project_root: str
    llm_provider: str = "none"      # "claude" | "gpt" | "grok" | "inhouse" | "none"
    llm_api_key: Optional[str] = None
    llm_model: Optional[str] = None
    test_command: Optional[str] = None
    auto_heal: bool = True
    detect_equivalents: bool = True


class JobResponse(BaseModel):
    job_id: str
    stream_url: str


# ── Helpers ────────────────────────────────────────────────────────────────

def _emit(queue: asyncio.Queue, event_type: str, data: dict):
    """Push a typed SSE event onto the queue."""
    asyncio.get_event_loop().call_soon_threadsafe(
        queue.put_nowait, {"type": event_type, **data}
    )


# ── Core analysis pipeline ─────────────────────────────────────────────────

async def _run_analysis(job_id: str, queue: asyncio.Queue, req: AnalyzeRequest):
    try:
        # Build components
        kwargs = {}
        if req.llm_api_key:
            kwargs["api_key"] = req.llm_api_key
        if req.llm_model:
            kwargs["model"] = req.llm_model

        llm = create_adapter(req.llm_provider, **kwargs)
        detector = EquivalentDetector(llm_adapter=llm if req.detect_equivalents else None)
        runner = TestRunner(req.project_root, req.test_command)
        healer = AutoHealer(llm, req.project_root) if req.auto_heal else None
        engine = MutationEngine()

        # ── Baseline check ──
        await queue.put({"type": "status", "message": "Running baseline tests..."})
        baseline_ok = await runner.run_baseline()
        if not baseline_ok:
            await queue.put({
                "type": "error",
                "message": "Baseline tests FAILED. Fix your tests before running AMIL."
            })
            return

        # ── Generate mutants ──
        await queue.put({"type": "status", "message": "Generating mutants..."})
        mutants = engine.generate_mutants(req.file_path)
        total = len(mutants)

        await queue.put({
            "type": "start",
            "total": total,
            "file": Path(req.file_path).name,
            "llm_provider": llm.name,
        })

        if total == 0:
            await queue.put({"type": "complete",
                             "message": "No mutants generated. Add more logic to your code."})
            return

        # ── Per-mutant pipeline ──
        killed = survived = equivalent = errors = 0

        for i, mutant in enumerate(mutants, 1):
            # ── Step A: Equivalence check ──
            equiv_result = await detector.classify(mutant.original_src, mutant.mutant_src)

            if equiv_result.equivalent:
                mutant.status = "equivalent"
                mutant.equivalent_reason = equiv_result.reason
                equivalent += 1
                await queue.put({
                    "type": "mutant_result",
                    "index": i, "total": total,
                    "mutant_id": mutant.id,
                    "function": mutant.function_name,
                    "line": mutant.line_no,
                    "operator": mutant.operator,
                    "description": mutant.description,
                    "status": "equivalent",
                    "reason": equiv_result.reason,
                    "method": equiv_result.method,
                    "killed": killed, "survived": survived,
                    "equivalent": equivalent, "errors": errors,
                    "true_score": _score(killed, survived),
                    "raw_score": _raw_score(killed, survived, equivalent),
                })
                continue

            # ── Step B: Run tests ──
            result = await runner.run_mutant(mutant)
            mutant.status = result

            if result == "killed":
                killed += 1
            elif result == "survived":
                survived += 1
            else:
                errors += 1

            heal_result = None

            # ── Step C: Auto-heal survived mutants ──
            if result == "survived" and healer and llm.name != "none":
                await queue.put({
                    "type": "healing",
                    "mutant_id": mutant.id,
                    "message": f"Writing test to kill {mutant.id}..."
                })
                heal_result = await healer.heal(mutant)
                mutant.suggested_test = heal_result.test_code

            await queue.put({
                "type": "mutant_result",
                "index": i, "total": total,
                "mutant_id": mutant.id,
                "function": mutant.function_name,
                "line": mutant.line_no,
                "operator": mutant.operator,
                "description": mutant.description,
                "status": result,
                "killed": killed, "survived": survived,
                "equivalent": equivalent, "errors": errors,
                "true_score": _score(killed, survived),
                "raw_score": _raw_score(killed, survived, equivalent),
                "suggested_test": heal_result.test_code if heal_result else None,
                "test_verified": heal_result.verified if heal_result else None,
            })

        # ── Final summary ──
        summary = {
            "type": "complete",
            "total": total,
            "killed": killed,
            "survived": survived,
            "equivalent": equivalent,
            "errors": errors,
            "true_score": _score(killed, survived),
            "raw_score": _raw_score(killed, survived, equivalent),
            "llm_provider": llm.name,
        }
        _job_summaries[job_id] = summary
        await queue.put(summary)

    except Exception as e:
        await queue.put({"type": "error", "message": str(e)})


def _score(killed: int, survived: int) -> float:
    """True mutation score — excludes equivalents."""
    total = killed + survived
    return round(killed / total * 100, 1) if total > 0 else 0.0


def _raw_score(killed: int, survived: int, equivalent: int) -> float:
    """Naive score — includes equivalents in denominator."""
    total = killed + survived + equivalent
    return round(killed / total * 100, 1) if total > 0 else 0.0


# ── API Endpoints ──────────────────────────────────────────────────────────

@app.post("/analyze", response_model=JobResponse)
async def start_analysis(req: AnalyzeRequest):
    if not Path(req.file_path).exists():
        raise HTTPException(400, f"File not found: {req.file_path}")
    if not Path(req.project_root).exists():
        raise HTTPException(400, f"Project root not found: {req.project_root}")

    job_id = str(uuid.uuid4())
    queue: asyncio.Queue = asyncio.Queue()
    _jobs[job_id] = queue

    asyncio.create_task(_run_analysis(job_id, queue, req))

    return JobResponse(
        job_id=job_id,
        stream_url=f"http://localhost:8765/stream/{job_id}"
    )


@app.get("/stream/{job_id}")
async def stream_results(job_id: str):
    if job_id not in _jobs:
        raise HTTPException(404, f"Job {job_id} not found")

    queue = _jobs[job_id]

    async def event_generator():
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=120)
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") in ("complete", "error"):
                    break
            except asyncio.TimeoutError:
                yield "data: {\"type\": \"ping\"}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/summary/{job_id}")
async def get_summary(job_id: str):
    if job_id not in _job_summaries:
        raise HTTPException(404, "Summary not ready yet")
    return _job_summaries[job_id]


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


# ── Entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="warning")
